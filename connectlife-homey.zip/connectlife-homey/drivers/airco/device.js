'use strict';

const Homey = require('homey');

// ConnectLife airco-eigenschappen (zie connectlife-ha data_dictionaries/009.yaml):
//   t_power: 0/1            t_work_mode: 0 fan_only, 1 heat, 2 cool, 3 dry, 4 auto
//   t_temp: setpoint (C)    f_temp_in: kamertemperatuur
//   t_fan_speed: 0 auto, 5 low, 6 middle_low, 7 medium, 8 middle_high, 9 high
//   t_eco: 0/1
const MODE_BY_NUM = { 0: 'fan_only', 1: 'heat', 2: 'cool', 3: 'dry', 4: 'auto' };
const NUM_BY_MODE = Object.fromEntries(Object.entries(MODE_BY_NUM).map(([k, v]) => [v, Number(k)]));
const FAN_BY_NUM = { 0: 'auto', 5: 'low', 6: 'middle_low', 7: 'medium', 8: 'middle_high', 9: 'high' };
const NUM_BY_FAN = Object.fromEntries(Object.entries(FAN_BY_NUM).map(([k, v]) => [v, Number(k)]));

const POLL_MS = 60 * 1000;
const FAST_POLL_MS = 8 * 1000; // kort na een commando, om de nieuwe stand te bevestigen

module.exports = class AircoDevice extends Homey.Device {
  async onInit() {
    this._puid = this.getData().puid;
    this._deviceId = this.getData().id;
    this._busy = false;

    this.registerCapabilityListener('onoff', v => this._set({ t_power: v ? 1 : 0 }));
    this.registerCapabilityListener('target_temperature', v => this._set({ t_temp: Math.round(v) }));
    this.registerCapabilityListener('connectlife_mode', v => {
      if (!(v in NUM_BY_MODE)) throw new Error(`Onbekende modus ${v}`);
      // Een modus kiezen zet het toestel ook aan.
      return this._set({ t_power: 1, t_work_mode: NUM_BY_MODE[v] });
    });
    this.registerCapabilityListener('connectlife_fan', v => {
      if (!(v in NUM_BY_FAN)) throw new Error(`Onbekende ventilatorstand ${v}`);
      return this._set({ t_fan_speed: NUM_BY_FAN[v] });
    });
    this.registerCapabilityListener('connectlife_eco', v => this._set({ t_eco: v ? 1 : 0 }));

    // Flow-kaarten (v0.3.0)
    const fl = this.homey.flow;
    this._trgMode = fl.getDeviceTriggerCard('connectlife_mode_changed');
    this._trgFan = fl.getDeviceTriggerCard('connectlife_fan_changed');
    this._trgEco = fl.getDeviceTriggerCard('connectlife_eco_changed');
    const reg = (id, fn) => fl.getConditionCard(id).registerRunListener(fn);
    reg('connectlife_mode_is', (a) => a.device.getCapabilityValue('connectlife_mode') === a.mode);
    reg('connectlife_fan_is', (a) => a.device.getCapabilityValue('connectlife_fan') === a.fan);
    reg('connectlife_eco_is_on', (a) => a.device.getCapabilityValue('connectlife_eco') === true);
    fl.getActionCard('connectlife_set_mode').registerRunListener(a => a.device.triggerCapabilityListener('connectlife_mode', a.mode));
    fl.getActionCard('connectlife_set_fan').registerRunListener(a => a.device.triggerCapabilityListener('connectlife_fan', a.fan));
    fl.getActionCard('connectlife_set_eco').registerRunListener(a => a.device.triggerCapabilityListener('connectlife_eco', a.eco === 'on'));

    fl.getActionCard('connectlife_set_external_temp').registerRunListener(async a => a.device.setExternalTemp(a.temperature));
    fl.getActionCard('connectlife_clear_external_temp').registerRunListener(async a => a.device.clearExternalTemp());

    fl.getActionCard('connectlife_set_external_humidity').registerRunListener(async a => a.device.setExternalHumidity(a.humidity));
    fl.getActionCard('connectlife_clear_external_humidity').registerRunListener(async a => a.device.clearExternalHumidity());

    // Extra meetwaarden (v0.2.0): bij bestaande toestellen toevoegen zonder opnieuw te koppelen.

    await this._poll();
    this._timer = this.homey.setInterval(() => this._poll(), POLL_MS);
  }

  async onDeleted() {
    if (this._timer) this.homey.clearInterval(this._timer);
    if (this._fast) this.homey.clearTimeout(this._fast);
  }

  // Externe sensor (v0.4.0): een flow geeft de temperatuur van bv. de living-sensor door. Zolang die
  // maximaal 60 min oud is, vervangt ze de interne sensor van de airco.
  _externFris() {
    const e = this._ext;
    return !!(e && typeof e.value === 'number' && Date.now() - e.ts < 60 * 60 * 1000);
  }

  async setExternalTemp(t) {
    const v = Number(t);
    if (!(v > -40 && v < 80)) throw new Error('Ongeldige temperatuur');
    this._ext = { value: v, ts: Date.now() };
    this._cap('measure_temperature', v);
  }

  async clearExternalTemp() {
    this._ext = null;
    if (this._internTemp !== undefined) this._cap('measure_temperature', this._internTemp);
  }

  // Externe vochtigheid (v0.5.0): enkel weergave in Homey, max. 60 min oud.
  async setExternalHumidity(h) {
    const v = Number(h);
    if (!(v >= 0 && v <= 100)) throw new Error('Ongeldige vochtigheid');
    this._extHum = { value: v, ts: Date.now() };
    this._cap('measure_humidity', v);
  }

  async clearExternalHumidity() {
    this._extHum = null;
    if (this.hasCapability('measure_humidity')) await this.removeCapability('measure_humidity').catch(() => {});
  }

  async _set(props) {
    const api = this.homey.app.getApi();
    if (!api) throw new Error('Niet ingelogd bij ConnectLife');
    this.log('Zet', JSON.stringify(props));
    await api.setProperties(this._puid, props);
    if (this._fast) this.homey.clearTimeout(this._fast);
    this._fast = this.homey.setTimeout(() => this._poll(), FAST_POLL_MS);
  }

  async _poll() {
    if (this._busy) return;
    this._busy = true;
    try {
      const api = this.homey.app.getApi();
      if (!api) { await this.setUnavailable('Niet ingelogd bij ConnectLife'); return; }
      const list = await api.getAppliances();
      const me = list.find(d => String(d.deviceId) === this._deviceId);
      if (!me) { await this.setUnavailable('Toestel niet gevonden in ConnectLife'); return; }
      if (String(me.offlineState) === '0') { await this.setUnavailable('Airco is offline'); return; }
      await this.setAvailable();
      this._apply(me.statusList || {});
    } catch (e) {
      this.error('Poll mislukt:', e.message);
      await this.setUnavailable(`ConnectLife: ${e.message}`).catch(() => {});
    } finally {
      this._busy = false;
    }
  }

  _apply(s) {
    // Diagnose: alle ontvangen eigenschappen zichtbaar in de geavanceerde instellingen van het toestel.
    try {
      const txt = Object.keys(s).sort().map(k => `${k}=${s[k]}`).join(', ');
      if (txt !== this._lastDiag) { this._lastDiag = txt; this.setSettings({ diagnose: txt.slice(0, 2000) }).catch(() => {}); }
    } catch (e) { /* diagnose is optioneel */ }
    const num = k => (s[k] === undefined || s[k] === null || s[k] === '' ? null : Number(s[k]));
    const power = num('t_power');
    if (power !== null) this._cap('onoff', power === 1);
    const t = num('t_temp');
    if (t !== null) this._cap('target_temperature', t);
    const tin = num('f_temp_in');
    if (tin !== null && tin > -40 && tin < 80) {
      this._internTemp = tin;
      if (!this._externFris()) this._cap('measure_temperature', tin);
    }
    const m = num('t_work_mode');
    if (m !== null && MODE_BY_NUM[m]) this._cap('connectlife_mode', MODE_BY_NUM[m]);
    const f = num('t_fan_speed');
    if (f !== null && FAN_BY_NUM[f]) this._cap('connectlife_fan', FAN_BY_NUM[f]);
    // Buitentemperatuur: de naam verschilt per model, dus zoeken op patroon (f_temp_out, outdoor, ...).
    const buitenKey = ['f_temp_out', 'f_outdoor_temp', 'f_temp_outdoor', 't_temp_out', 'f_out_temp'].find(k => s[k] !== undefined)
      || Object.keys(s).find(k => /(temp.*(out|outdoor)|(out|outdoor).*temp)/i.test(k) && !/^f_e_/i.test(k) && !/(coil|pipe|exhaust|comp|gastemp)/i.test(k));
    if (buitenKey) {
      const tb = num(buitenKey);
      if (tb !== null && tb > -50 && tb < 80) this._cap('measure_temperature.outdoor', tb);
    }
    const pw = num('f_power_display');
    if (pw !== null && pw >= 0 && pw < 10000) this._cap('measure_power', pw);
    const kwh = num('f_power_consumption');
    if (kwh !== null && kwh >= 0) this._cap('meter_power', kwh);
    const hum = num('f_humidity');
    if (hum !== null && hum >= 0 && hum <= 100) this._cap('measure_humidity', hum);
    // Optionele meetwaarden die dit toestel NIET levert weer verwijderen (geen lege tegels).
    const geleverd = new Set();
    if (buitenKey) geleverd.add('measure_temperature.outdoor');
    if (pw !== null) geleverd.add('measure_power');
    if (kwh !== null) geleverd.add('meter_power');
    if (hum !== null) geleverd.add('measure_humidity');
    for (const c of ['measure_temperature.outdoor', 'measure_power', 'meter_power', 'measure_humidity']) {
      const externVocht = (c === 'measure_humidity' && this._extHum && Date.now() - this._extHum.ts < 60 * 60 * 1000);
      if (!geleverd.has(c) && !externVocht && this.hasCapability(c)) this.removeCapability(c).catch(() => {});
    }
    const eco = num('t_eco');
    if (eco !== null) this._cap('connectlife_eco', eco === 1);
  }

  _cap(id, value) {
    const OPTIONEEL = ['measure_temperature.outdoor', 'measure_power', 'meter_power', 'measure_humidity'];
    if (OPTIONEEL.includes(id) && !this.hasCapability(id)) {
      this.addCapability(id).then(() => this.setCapabilityValue(id, value)).catch(e => this.error('addCapability', id, e.message));
      return;
    }
    if (this.hasCapability(id) && this.getCapabilityValue(id) !== value) {
      this.setCapabilityValue(id, value).then(() => {
        if (id === 'connectlife_mode' && this._trgMode) this._trgMode.trigger(this, { mode: value }).catch(() => {});
        if (id === 'connectlife_fan' && this._trgFan) this._trgFan.trigger(this, { fan: value }).catch(() => {});
        if (id === 'connectlife_eco' && this._trgEco) this._trgEco.trigger(this, { eco: value }).catch(() => {});
      }).catch(e => this.error('setCapabilityValue', id, e.message));
    }
  }
};
